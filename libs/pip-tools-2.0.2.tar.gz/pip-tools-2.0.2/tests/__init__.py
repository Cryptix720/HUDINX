# Trigger an import of piptools, effectively injecting piptools/_vendored in sys.path
import piptools  # noqa

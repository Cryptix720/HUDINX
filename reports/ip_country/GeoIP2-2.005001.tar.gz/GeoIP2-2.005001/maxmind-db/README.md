MaxMind DB is a binary file format that stores data indexed by IP address
subnets (IPv4 or IPv6).

This repository contains the spec for that format.
